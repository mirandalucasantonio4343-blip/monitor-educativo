# Monitor Educativo PBA + Nación — Guía de instalación en la nube (gratis)

Corre en **GitHub Actions**: gratis, sin tarjeta, sin servidor propio.
El token queda guardado cifrado en GitHub Secrets, nunca en el código.

## Archivos incluidos
- `monitor_educativo.py` — el bot.
- `requirements.txt` — librerías que necesita.
- `.github/workflows/monitor.yml` — el "reloj" que lo dispara cada 15 minutos.

## Pasos

### 1. Preparar Telegram
- En @BotFather, generá un token nuevo (`/token`).
- Abrí el chat con tu bot y mandale **/start** (imprescindible).

### 2. Crear el repositorio
- Entrá a github.com, creá una cuenta si no tenés.
- Botón **New repository**. Nombre: `monitor-educativo`.
- Elegí **Public** (los repos públicos tienen minutos de Actions ILIMITADOS y gratis).
  El token NO queda expuesto porque va en Secrets, no en el código.
- Subí estos tres archivos respetando la carpeta `.github/workflows/`.

### 3. Cargar los secretos (token y chat)
En el repo: **Settings → Secrets and variables → Actions → New repository secret**.
Creá dos:
- `TOKEN_TELEGRAM` = tu token nuevo
- `CHAT_ID_TELEGRAM` = 6631546663

### 4. Activar y probar
- Pestaña **Actions** → si pide habilitar workflows, aceptá.
- Elegí **Monitor Educativo** → **Run workflow** para probar ahora mismo.
- Si todo está bien, en 1–2 minutos empiezan a llegar los mensajes.

A partir de ahí corre solo cada 15 minutos.

## Notas
- GitHub pausa los cron si el repo no tiene actividad por 60 días: entrá cada tanto
  o hacé un cambio menor para reactivarlo.
- Los horarios del cron pueden atrasarse algunos minutos en momentos de mucha demanda.
- Para ajustar frecuencia, editá el `cron` del workflow y `INTERVALO_MINUTOS` no aplica
  en la nube (ahí manda el cron de GitHub).
